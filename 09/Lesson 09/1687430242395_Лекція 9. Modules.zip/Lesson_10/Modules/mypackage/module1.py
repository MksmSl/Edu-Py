
def sum_three_numbers(a, b, c):
    return a + b + c
