# import <module_name>
import utils

# module_name.function_name()
value = utils.add(2, 2)
print(value)

# double_value = utils.square(value)
# print(double_value)

# ---------------------------------------

# from utils import add

# function_name()
# value1 = add(2, 2)
# value2 = add(3, 5)

# print(square(2))
